package com.kita.store

class GlobalData {

    companion object{
        var client_id:String = "AQxKQV8Y4WHO_NCtqwQ-752W-I0db6J6tQcKt2g3FNqq31hovjmEejniQmkOwpJL5LkGvbYpw4trQp17"
        var secret:String = "EOHFhYWrTud6QEYAjZsbawoCzfZQQbH7n1qs4_s61rX8lN_e3KNr9za00B7xnMMAf-H8yBzgkmuVLYKc"
        var email:String = String()
        var idCategory:Int = 0
        var ids: Int = 0;
        var names:String = String()
        var hargas:Int = 0
        var photos:String = String()
        var deskripsis:String = String()
        var catatan:String = String()
        var jumlah: Int = 0
    }
}