package com.kita.store.modal

class Category {

    var id:Int
    var nama:String;
    var photo:String

    constructor(id: Int, nama: String, photo: String) {
        this.id = id
        this.nama = nama
        this.photo = photo
    }
}