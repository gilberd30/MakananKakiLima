package com.inyongtisto.tokoonline.model

class User {
    lateinit var email:String
    lateinit var name:String
    lateinit var phone:String
    var id = 0
}