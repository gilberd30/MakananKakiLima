package com.inyongtisto.tokoonline.util

/**
 * Created by Tisto on 1/11/2021.
 */
object Config {
    const val baseUrl = "http://192.168.43.231/tokoonline/public/"
    const val productUrl = baseUrl + "storage/produk/"
}