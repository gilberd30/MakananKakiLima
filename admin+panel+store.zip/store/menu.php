<a href="addcategory.php">CATEGORY</a> |
				<a href="addproduct.php">PRODUCT</a> |
				<a href="categoryview.php">CATEGORY VIEW</a> |
				<a href="productview.php">PRODUCT VIEW</a>