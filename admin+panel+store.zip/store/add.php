<?php
	
	$nama = "Supriyanto";
	$umur = 1;

	// for ($i=0; $i < $umur; $i++) { 
		
	// 	echo $i;
	// 	echo "</br>";

	// }

	while ($umur <= 10) {
		
		echo $umur++;
	}

	do {
		echo $umur++;
	} while ($umur <= 10);
?>