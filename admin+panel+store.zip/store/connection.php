<?php
	error_reporting(0);
	$host = "localhost";
	$name = "root";
	$pass = "";
	$db = "store";

	$conn = mysqli_connect($host, $name, $pass, $db);
?>